<?php
/**
 * Created by PhpStorm.
 * User: wh1t3P1g
 * Date: 2018/4/5
 * Time: 22:06
 */

spl_autoload_register(function ($class_name) {
    require_once 'lib/'.$class_name . '.php';
});

/* database config */
$pdo="mysql:host=localhost;dbname=test";
$user="Administrator";
$pass="";

$db=new Database($pdo,$user,$pass);
$len=strlen($_SERVER['PHP_SELF']);

if(substr($_SERVER['PHP_SELF'],$len-9,$len)=="index.php"){
	$php_self=substr($_SERVER['PHP_SELF'],0,$len-9);
}
else{
	$php_self=$_SERVER['PHP_SELF'];
}
$uri='http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);

function check(){
    if(isset($_SESSION['login'])&&$_SESSION['login']==true)
        return true;
    else
        return false;
}

function logout(){
    unset($_SESSION['login']);
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-42000, '/');
    }
    session_destroy();
}
