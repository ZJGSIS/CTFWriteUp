<?php
/**
 * Created by PhpStorm.
 * User: wh1t3P1g
 * Date: 2018/4/4
 * Time: 22:45
 */
session_start();
include "../config.php";
// alter php.ini session.cookie_httponly=1 stop xss
if(check()){
    $path=isset($_GET['path'])&&$_GET['path']?$_GET['path']:'view';
    switch($path){
        case 'view':
            include "view.php";
            break;
        case 'login':
            include "login.php";
            break;
        case 'logout':
            logout();

            header("Location: ".$uri);
            break;
        default:
            include "http://localhost/".$_GET['path'];
            //TODO: not sure how to request intranet application
            //TODO: give me some time to work out
            //TODO: keep that way for now!
    }
}else{
    include "login.php";
}