<meta http-equiv="refresh" content="3">

<?php
/**
 * Created by PhpStorm.
 * User: wh1t3P1g
 * Date: 2018/4/6
 * Time: 12:30
 */
if(!check()){
    $uri="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
    header("Location: ".$uri."/index.php?path=login");
    die();
}
$db->init();
$msg=$db->viewMessage();
include "../layout/view.html";
