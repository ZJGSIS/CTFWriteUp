<?php
/**
 * Created by PhpStorm.
 * User: wh1t3P1g
 * Date: 2018/4/6
 * Time: 12:29
 */
if(check()){
    $uri="http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
    header("Location: ".$uri."/index.php?path=view");
    die();
}
if(isset($_POST['submit'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    if($username&&$password){
        $db->init();
        if($db->loginCheck($username,$password)){
            $_SESSION['login']=true;
            var_dump($_SESSION);
            header("Location: ".$uri."/index.php?path=view");
            die("Login success");
        }
        else{
            echo "believe me!don't try getting in!</br>flag is not here!";
        }
    }
}else{
    include "../layout/login.html";
}
